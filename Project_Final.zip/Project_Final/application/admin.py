from django.contrib import admin
from application.models import *


# Register your models here.

admin.site.register(enquiry_table)
admin.site.register(DropdownOption)

